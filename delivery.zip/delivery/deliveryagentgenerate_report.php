<?php
require_once '../config/dbConnect.php';
require('../fpdf/fpdf.php');

session_start();
if (!isset($_SESSION['Email_id']) || $_SESSION['user_type'] !== 'Delivery Agent') {
    die("Unauthorized Access!");
}

$email = $_SESSION['Email_id'];
$selectedMonth = isset($_POST['month']) ? $_POST['month'] : date('Y-m');
$selectedYear = isset($_POST['year']) ? $_POST['year'] : date('Y');

// Fetch total delivered orders (All-time)
$countQuery = "SELECT COUNT(*) AS total_orders FROM order_history_table WHERE Email_Id = ?";
$stmt = $conn->prepare($countQuery);
$stmt->bind_param("s", $email);
$stmt->execute();
$countResult = $stmt->get_result();
$totalOrders = $countResult->fetch_assoc()['total_orders'];
$stmt->close();

// Fetch total orders for selected month
$monthlyCountQuery = "SELECT COUNT(*) AS monthly_orders FROM order_history_table WHERE Email_Id = ? AND DATE_FORMAT(Delivery_Date, '%Y-%m') = ?";
$stmt = $conn->prepare($monthlyCountQuery);
$stmt->bind_param("ss", $email, $selectedMonth);
$stmt->execute();
$monthlyCountResult = $stmt->get_result();
$monthlyOrders = $monthlyCountResult->fetch_assoc()['monthly_orders'];
$stmt->close();

// Fetch order history filtered by selected month
$query = "
    SELECT oh.History_Id, oh.Order_Id, oh.Delivery_Date 
    FROM order_history_table oh
    WHERE oh.Email_Id = ? AND DATE_FORMAT(oh.Delivery_Date, '%Y-%m') = ?
    ORDER BY oh.Delivery_Date DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $email, $selectedMonth);
$stmt->execute();
$result = $stmt->get_result();
$orderHistory = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();

// Generate PDF Report
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, "------------PartsMart---------", 0, 1, 'C');
$pdf->Cell(190, 10, "------------Agent Order History Report---------", 0, 1, 'C');
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 12);

// Display selected month and year
$pdf->Cell(190, 10, "Selected Month: " . $selectedMonth, 0, 1, 'C');
$pdf->Ln(5);

// Display total orders (All-time, Monthly, Yearly)
$pdf->Cell(190, 10, "Total Orders Delivered (All Time): " . $totalOrders, 0, 1, 'C');
$pdf->Cell(190, 10, "Total Orders Delivered (This Month): " . $monthlyOrders, 0, 1, 'C');
$pdf->Ln(10);

// Table Header
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(40, 10, 'History ID', 1, 0, 'C');
$pdf->Cell(60, 10, 'Order ID', 1, 0, 'C');
$pdf->Cell(50, 10, 'Delivery Date', 1, 1, 'C');

$pdf->SetFont('Arial', '', 12);
if (!empty($orderHistory)) {
    foreach ($orderHistory as $history) {
        $pdf->Cell(40, 10, htmlspecialchars($history['History_Id']), 1, 0, 'C');
        $pdf->Cell(60, 10, htmlspecialchars($history['Order_Id']), 1, 0, 'C');
        $pdf->Cell(50, 10, htmlspecialchars($history['Delivery_Date']), 1, 1, 'C');
    }
} else {
    $pdf->Cell(150, 10, 'No orders found for the selected month.', 1, 1, 'C');
}

// Output the PDF
$pdf->Output('D', "Partsmart_agent_Report_$selectedMonth.pdf");
exit();