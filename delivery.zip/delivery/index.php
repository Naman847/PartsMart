<?php
// Set default page to 'order-status'
$page = isset($_GET['page']) ? $_GET['page'] : 'order-status'; 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Agent</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <nav class="sidebar">
            <h2>Delivery Agent</h2>
            <ul>
                <li><a href="?page=login-manage" id="profile-link"><i class="fa-solid fa-circle-user"></i><span>Agent Profile</span></a></li>
               
                <li><a href="?page=order-status" id="orders-link"><i class="fa-solid fa-cart-shopping"></i><span>Order Details</span></a></li>
                <li><a href="?page=order-history" id="orders-link"><i class="fa-solid fa-cart-shopping"></i><span>Order History</span></a></li>
                <li><a href="?page=logout" id="logout-link"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Log Out</span></a></li>
            </ul>
        </nav>

        <!-- Main Content Area -->
        <div class="main-content">
            <?php
            // PHP Logic to load content dynamically based on the page parameter
            switch ($page) {
                case 'login-manage':
                    include('login-manage.php');
                    break;
                case 'order-status':
                    include('OrderStatus.php');
                    break;
                case 'order-history':
                    include('orderdata.php');
                    break;
                    case 'logout':
                        header("Location: ../client/logout.php"); // Redirect to login page
                        exit();                    
                default:
                    header("Location: OrderStatus.php");
            }
            ?>
        </div>
    </div>

    <script>
    

        // Highlight the active link in the sidebar
        document.querySelectorAll('.sidebar a').forEach(link => {
            if (link.getAttribute('href') === `?page=<?php echo $page; ?>`) {
                link.classList.add('active');
            }
        });
    </script>
</body>

</html>
