<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['isLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// Database connection
require_once '../config/dbConnect.php';

// Function to fetch user data from database
function getUserData($conn, $email)
{
    try {
        $sql = "SELECT Email_Id, First_Name, Last_Name, Gender, Address, Pincode, Phone_Number, User_Type 
                FROM user_detail_tbl 
                WHERE Email_Id = ?";

        if (!$stmt = $conn->prepare($sql)) {
            error_log("Prepare failed: " . $conn->error);
            return null;
        }

        $stmt->bind_param("s", $email);

        if (!$stmt->execute()) {
            error_log("Execute failed: " . $stmt->error);
            return null;
        }

        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            error_log("No user found with email: " . $email);
            return null;
        }

        return $result->fetch_assoc();
    } catch (Exception $e) {
        error_log("Database error: " . $e->getMessage());
        return null;
    }
}

// Get user data using email from session
$userData = getUserData($conn, $_SESSION['Email_id']);

// Handle form submission for profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $email = $_SESSION['Email_id']; // Use email as identifier

        // Prepare the UPDATE query
        $sql = "UPDATE user_detail_tbl SET 
                First_Name = ?,
                Last_Name = ?,
                Phone_Number = ?,
                Gender = ?,
                Address = ?,
                Pincode = ?
                WHERE Email_Id = ?";

        if (!$stmt = $conn->prepare($sql)) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        // Bind parameters
        $stmt->bind_param(
            "sssssss",
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['phone'],
            $_POST['gender'],
            $_POST['address'],
            $_POST['pincode'],
            $email // Email as identifier
        );

        // Execute the UPDATE query
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }

        // Update session data
        $_SESSION['user_name'] = $_POST['first_name'] . ' ' . $_POST['last_name'];
        $_SESSION['phone'] = $_POST['phone'];
        $_SESSION['address'] = $_POST['address'];
        $_SESSION['pincode'] = $_POST['pincode'];

        // Return success response
        echo json_encode(["status" => "success", "message" => "Profile updated successfully!"]);
        exit();
    } catch (Exception $e) {
        error_log("Error updating profile: " . $e->getMessage());
        echo json_encode(["status" => "error", "message" => "Failed to update profile. Please try again."]);
        exit();
    }
}

// Format user data for the form (with session fallbacks)
$formData = [
    'first_name' => $userData['First_Name'] ?? explode(' ', $_SESSION['user_name'])[0] ?? '',
    'last_name' => $userData['Last_Name'] ?? explode(' ', $_SESSION['user_name'])[1] ?? '',
    'email' => $userData['Email_Id'] ?? $_SESSION['Email_id'] ?? '',
    'phone' => $userData['Phone_Number'] ?? $_SESSION['phone'] ?? '',
    'gender' => $userData['Gender'] ?? '',
    'address' => $userData['Address'] ?? $_SESSION['address'] ?? '',
    'pincode' => $userData['Pincode'] ?? $_SESSION['pincode'] ?? ''
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Profile</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Keep the existing CSS styles from login-manage.php */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .profile-container {
            width: 600px;
            margin: 3rem auto;
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .profile-container h2 {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .profile-group {
            margin-bottom: 1rem;
        }

        .profile-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        .profile-group input {
            width: 100%;
            padding: 0.6rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #222;
        }

        .btn-secondary {
            background-color: #555;
        }

        .btn-secondary:hover {
            background-color: #444;
        }

        #saveBtn {
            background-color: green;
            display: none;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="profile-container">
        <h2>Agent Profile</h2>
        <form id="profileForm">
            <div class="profile-group">
                <label>First Name:</label>
                <input type="text" name="first_name" id="first_name"
                    value="<?= htmlspecialchars($formData['first_name']); ?>" required readonly>
                <div id="first_name_error" class="error-message"></div>
            </div>

            <div class="profile-group">
                <label>Last Name:</label>
                <input type="text" name="last_name" id="last_name"
                    value="<?= htmlspecialchars($formData['last_name']); ?>" required readonly>
                <div id="last_name_error" class="error-message"></div>
            </div>

            <div class="profile-group">
                <label>Email:</label>
                <input type="email" name="email" value="<?= htmlspecialchars($formData['email']); ?>" readonly>
            </div>

            <div class="profile-group">
                <label>Phone Number:</label>
                <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($formData['phone']); ?>" required
                    readonly>
                <div id="phone_error" class="error-message"></div>
            </div>

            <div class="profile-group">
                <label>Gender:</label>
                <select id="gender" name="gender" required readonly>
                    <option value="Male" <?php echo ($formData['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?php echo ($formData['gender'] == 'Female') ? 'selected' : ''; ?>>Female
                    </option>
                    <option value="Other" <?php echo ($formData['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                </select>
                <div id="gender_error" class="error-message"></div>
            </div>

            <div class="profile-group">
                <label>Address:</label>
                <input type="text" name="address" id="address" value="<?= htmlspecialchars($formData['address']); ?>"
                    required readonly>
                <div id="address_error" class="error-message"></div>
            </div>

            <div class="profile-group">
                <label>Pincode:</label>
                <input type="text" name="pincode" id="pincode" value="<?= htmlspecialchars($formData['pincode']); ?>"
                    required readonly>
                <div id="pincode_error" class="error-message"></div>
            </div>

            <div class="button-group">
                <a href="../client/change_password.php">Change Password</a>
                <button type="submit" id="saveBtn" class="btn">Save</button>
                <button type="button" id="editBtn" class="btn">Update Profile</button>
                <a href="index.php" class="btn btn-secondary">Back</a>
            </div>
        </form>
    </div>

    <script>
        // JavaScript to handle form editing and validation
        document.addEventListener('DOMContentLoaded', function () {
            const editBtn = document.getElementById('editBtn');
            const saveBtn = document.getElementById('saveBtn');
            const form = document.getElementById('profileForm');
            const inputs = form.querySelectorAll('input, select');

            // Enable editing when "Update Profile" is clicked
            editBtn.addEventListener('click', function () {
                inputs.forEach(input => {
                    if (input.name !== 'email') {
                        input.removeAttribute('readonly');
                    }
                });
                editBtn.style.display = 'none';
                saveBtn.style.display = 'inline-block';
            });

            // Form submission with validation
            form.addEventListener('submit', function (e) {
                e.preventDefault();

                let isValid = true;

                // Validate First Name
                const firstName = document.getElementById('first_name').value;
                const firstNameError = document.getElementById('first_name_error');
                if (!/^[A-Za-z]+$/.test(firstName)) {
                    firstNameError.textContent = 'First Name should only contain alphabets!';
                    isValid = false;
                } else {
                    firstNameError.textContent = '';
                }

                // Validate Last Name
                const lastName = document.getElementById('last_name').value;
                const lastNameError = document.getElementById('last_name_error');
                if (!/^[A-Za-z]+$/.test(lastName)) {
                    lastNameError.textContent = 'Last Name should only contain alphabets!';
                    isValid = false;
                } else {
                    lastNameError.textContent = '';
                }

                // Validate Phone Number
                const phone = document.getElementById('phone').value;
                const phoneError = document.getElementById('phone_error');
                if (!/^[6-9]\d{9}$/.test(phone)) {
                    phoneError.textContent = 'Please enter a valid Indian phone number!';
                    isValid = false;
                } else {
                    phoneError.textContent = '';
                }

                // Validate Address
                const address = document.getElementById('address').value;
                const addressError = document.getElementById('address_error');
                if (address.trim() === '') {
                    addressError.textContent = 'Address cannot be empty!';
                    isValid = false;
                } else {
                    addressError.textContent = '';
                }

                // Validate Pincode
                const pincode = document.getElementById('pincode').value;
                const pincodeError = document.getElementById('pincode_error');
                if (!/^3800[0-9][0-9]$/.test(pincode)) {
                    pincodeError.textContent = 'Please enter a valid Ahmedabad pincode!';
                    isValid = false;
                } else {
                    pincodeError.textContent = '';
                }

                // Submit form if valid
                if (isValid) {
                    const formData = new FormData(form);

                    fetch('login-manage.php', {
                        method: 'POST',
                        body: formData
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === "success") {
                                alert(data.message);
                                // Optionally, reset the form or update the UI
                            } else {
                                alert(data.message);
                            }
                        })
                        .catch(error => {
                            console.error("Error:", error);
                            alert("An error occurred. Please try again.");
                        });
                }
            });
        });
    </script>
</body>

</html>