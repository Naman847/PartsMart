<?php
require_once '../config/dbConnect.php';
require('../fpdf/fpdf.php');

// Start session
session_start();
if (!isset($_SESSION['Email_id']) || $_SESSION['user_type'] !== 'Delivery Agent') {
    echo "<p style='color: red;'>Unauthorized Access!</p>";
    exit;
}

$email = $_SESSION['Email_id'];

// Get selected month from the form (default: current month)
$selectedMonth = isset($_POST['month']) ? $_POST['month'] : date('Y-m');

// Count total orders delivered (overall)
$countQuery = "SELECT COUNT(*) AS total_orders FROM order_history_table WHERE Email_Id = ?";
$stmt = $conn->prepare($countQuery);
$stmt->bind_param("s", $email);
$stmt->execute();
$countResult = $stmt->get_result();
$totalOrders = $countResult->fetch_assoc()['total_orders'];
$stmt->close();

// Count total orders for the selected month
$monthCountQuery = "SELECT COUNT(*) AS month_total FROM order_history_table WHERE Email_Id = ? AND DATE_FORMAT(Delivery_Date, '%Y-%m') = ?";
$stmt = $conn->prepare($monthCountQuery);
$stmt->bind_param("ss", $email, $selectedMonth);
$stmt->execute();
$monthCountResult = $stmt->get_result();
$monthTotalOrders = $monthCountResult->fetch_assoc()['month_total'];
$stmt->close();

// Fetch order history filtered by selected month
$query = "
    SELECT oh.History_Id, oh.Order_Id, oh.Delivery_Date 
    FROM order_history_table oh
    WHERE oh.Email_Id = ? AND DATE_FORMAT(oh.Delivery_Date, '%Y-%m') = ?
    ORDER BY oh.Delivery_Date DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $email, $selectedMonth);
$stmt->execute();
$result = $stmt->get_result();
$orderHistory = [];

while ($row = $result->fetch_assoc()) {
    $orderHistory[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PartsMart - Order History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .order-counts {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
        }
        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            width: 200px;
        }
        .card h3 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }
        .card p {
            margin: 10px 0 0;
            font-size: 24px;
            font-weight: bold;
            color: #555;
        }
        .filter-form {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 15px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #333;
            color: #fff;
        }
        table tr:hover {
            background-color: #f5f5f5;
        }
        .no-data {
            text-align: center;
            color: red;
            font-size: 18px;
            margin-top: 20px;
        }
        /* Button Styles */
        button {
            background-color: #333;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <h1>Order History</h1>

    <!-- Order Counts in Card Style -->
    <div class="order-counts">
        <div class="card">
            <h3>Total Orders Delivered</h3>
            <p><?= htmlspecialchars($totalOrders) ?></p>
        </div>
        <div class="card">
            <h3>Orders in <?= htmlspecialchars($selectedMonth) ?></h3>
            <p><?= htmlspecialchars($monthTotalOrders) ?></p>
        </div>
    </div>

    <!-- Filter Form -->
    <form method="POST" class="filter-form">
        <label for="month">Select Month:</label>
        <input type="month" id="month" name="month" value="<?= htmlspecialchars($selectedMonth) ?>" required>
        <button type="submit">Filter</button>
    </form>

    <!-- Generate PDF Report -->
    <form method="POST" action="deliveryagentgenerate_report.php" target="_blank">
        <input type="hidden" name="month" value="<?= htmlspecialchars($selectedMonth) ?>">
        <button type="submit">Download Report</button>
    </form>

    <?php if (!empty($orderHistory)): ?>
        <table>
            <thead>
                <tr>
                    <th>Order History ID</th>
                    <th>Order ID</th>
                    <th>Delivery Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderHistory as $history): ?>
                    <tr>
                        <td><?= htmlspecialchars($history['History_Id']) ?></td>
                        <td><?= htmlspecialchars($history['Order_Id']) ?></td>
                        <td><?= htmlspecialchars($history['Delivery_Date']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="no-data">No order history found for the selected month.</p>
    <?php endif; ?>
</body>
</html>